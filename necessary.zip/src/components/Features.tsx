import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Smartphone, Monitor, Tv, Brain, Download, Globe } from "lucide-react";
import devicesImage from "@/assets/devices-ai.jpg";

const Features = () => {
  const features = [
    {
      icon: Brain,
      title: "AI-Powered Curation",
      description: "Machine learning algorithms that understand your unique taste and preferences."
    },
    {
      icon: Globe,
      title: "Global Content Library",
      description: "Access to millions of hours of content from around the world, in every language."
    },
    {
      icon: Download,
      title: "Smart Downloads",
      description: "AI predicts what you'll want to watch next and downloads it automatically."
    },
    {
      icon: Smartphone,
      title: "Multi-Device Sync",
      description: "Seamlessly switch between devices without losing your place."
    },
    {
      icon: Monitor,
      title: "4K Ultra HD",
      description: "Crystal clear picture quality with HDR support on compatible devices."
    },
    {
      icon: Tv,
      title: "Smart TV Integration",
      description: "Native apps for all major smart TV platforms with voice control."
    }
  ];

  return (
    <section className="py-20 px-4 bg-background">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-bold mb-6 text-foreground">
            Revolutionary Features
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Experience the future of entertainment with cutting-edge technology 
            that adapts to your lifestyle and preferences.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
          <div className="order-2 lg:order-1">
            <h3 className="text-3xl font-bold mb-6 text-foreground">
              Watch everywhere, on any device
            </h3>
            <p className="text-lg text-muted-foreground mb-8">
              Stream unlimited movies and TV shows on your phone, tablet, laptop, and TV. 
              Our AI ensures optimal quality and performance across all platforms.
            </p>
            <img 
              src={devicesImage} 
              alt="Streaming on multiple devices"
              className="w-full rounded-2xl shadow-card"
            />
          </div>
          
          <div className="order-1 lg:order-2 grid grid-cols-1 md:grid-cols-2 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card 
                  key={index} 
                  className="bg-gradient-card border-border/50 hover:shadow-glow transition-all duration-300 group"
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 rounded-lg bg-accent/20 group-hover:bg-accent/30 transition-colors">
                        <Icon className="w-6 h-6 text-accent" />
                      </div>
                      <CardTitle className="text-lg text-card-foreground">{feature.title}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-card-foreground/80">{feature.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;