import { Button } from "@/components/ui/button";

const Header = () => {
  return (
    <header className="absolute top-0 w-full z-50 px-4 py-6">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="text-primary text-2xl font-bold">
            AI<span className="text-accent">Stream</span>
          </div>
        </div>
        
        <nav className="hidden md:flex items-center space-x-8">
          <a href="#" className="text-foreground hover:text-accent transition-colors">Home</a>
          <a href="#" className="text-foreground hover:text-accent transition-colors">TV Shows</a>
          <a href="#" className="text-foreground hover:text-accent transition-colors">Movies</a>
          <a href="#" className="text-foreground hover:text-accent transition-colors">AI Picks</a>
        </nav>
        
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm">Sign In</Button>
          <Button variant="hero" size="sm">Get Started</Button>
        </div>
      </div>
    </header>
  );
};

export default Header;