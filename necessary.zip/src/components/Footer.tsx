import { Sparkles } from "lucide-react";

const Footer = () => {
  const links = {
    company: [
      "About Us",
      "Careers",
      "Press",
      "Investor Relations"
    ],
    support: [
      "Help Center",
      "Contact Us",
      "Device Support",
      "System Status"
    ],
    legal: [
      "Privacy Policy",
      "Terms of Service",
      "Cookie Preferences",
      "Legal Notices"
    ],
    features: [
      "AI Recommendations",
      "Smart Downloads",
      "4K Streaming",
      "Multi-Device"
    ]
  };

  return (
    <footer className="bg-background border-t border-border/50 py-16 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-8 mb-12">
          <div className="md:col-span-1">
            <div className="flex items-center space-x-2 mb-6">
              <Sparkles className="w-8 h-8 text-accent" />
              <div className="text-primary text-2xl font-bold">
                AI<span className="text-accent">Stream</span>
              </div>
            </div>
            <p className="text-muted-foreground text-sm leading-relaxed">
              The world's most advanced AI-powered streaming platform. 
              Discover content that truly matches your taste.
            </p>
          </div>
          
          <div>
            <h3 className="font-semibold text-foreground mb-4">Company</h3>
            <ul className="space-y-2">
              {links.company.map((link) => (
                <li key={link}>
                  <a href="#" className="text-muted-foreground hover:text-accent transition-colors text-sm">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-foreground mb-4">Support</h3>
            <ul className="space-y-2">
              {links.support.map((link) => (
                <li key={link}>
                  <a href="#" className="text-muted-foreground hover:text-accent transition-colors text-sm">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-foreground mb-4">Features</h3>
            <ul className="space-y-2">
              {links.features.map((link) => (
                <li key={link}>
                  <a href="#" className="text-muted-foreground hover:text-accent transition-colors text-sm">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-foreground mb-4">Legal</h3>
            <ul className="space-y-2">
              {links.legal.map((link) => (
                <li key={link}>
                  <a href="#" className="text-muted-foreground hover:text-accent transition-colors text-sm">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <div className="border-t border-border/50 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-muted-foreground text-sm mb-4 md:mb-0">
            © 2024 AIStream. All rights reserved. Powered by advanced machine learning.
          </p>
          <div className="flex items-center space-x-6">
            <a href="#" className="text-muted-foreground hover:text-accent transition-colors">
              <span className="sr-only">Facebook</span>
              <div className="w-5 h-5 bg-current rounded"></div>
            </a>
            <a href="#" className="text-muted-foreground hover:text-accent transition-colors">
              <span className="sr-only">Twitter</span>
              <div className="w-5 h-5 bg-current rounded"></div>
            </a>
            <a href="#" className="text-muted-foreground hover:text-accent transition-colors">
              <span className="sr-only">Instagram</span>
              <div className="w-5 h-5 bg-current rounded"></div>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;