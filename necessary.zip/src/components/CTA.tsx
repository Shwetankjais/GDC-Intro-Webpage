import { Button } from "@/components/ui/button";
import { Play, Sparkles, ArrowRight } from "lucide-react";

const CTA = () => {
  return (
    <section className="py-20 px-4 bg-gradient-hero relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-accent rounded-full animate-float"></div>
        <div className="absolute top-3/4 right-1/4 w-24 h-24 bg-primary rounded-full animate-float" style={{ animationDelay: "2s" }}></div>
        <div className="absolute top-1/2 left-3/4 w-16 h-16 bg-accent rounded-full animate-float" style={{ animationDelay: "4s" }}></div>
      </div>
      
      <div className="max-w-4xl mx-auto text-center relative z-10">
        <div className="mb-8">
          <Sparkles className="w-20 h-20 text-accent mx-auto mb-6 animate-glow" />
        </div>
        
        <h2 className="text-4xl md:text-6xl font-bold mb-6 text-foreground">
          Ready to experience the future of streaming?
        </h2>
        
        <p className="text-xl md:text-2xl text-foreground/80 mb-8 max-w-2xl mx-auto">
          Join millions of users who've discovered their next favorite shows 
          with our AI-powered recommendations.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
          <Button variant="hero" size="lg" className="group text-xl px-12 py-8">
            <Play className="w-6 h-6 mr-3 group-hover:scale-110 transition-transform" />
            Start Free Trial
            <ArrowRight className="w-6 h-6 ml-3 group-hover:translate-x-1 transition-transform" />
          </Button>
          <Button variant="ai" size="lg" className="group text-xl px-12 py-8">
            <Sparkles className="w-6 h-6 mr-3 group-hover:rotate-180 transition-transform duration-500" />
            Explore AI Features
          </Button>
        </div>
        
        <div className="flex flex-col sm:flex-row items-center justify-center space-y-2 sm:space-y-0 sm:space-x-8 text-sm text-foreground/60">
          <div className="flex items-center">
            <div className="w-2 h-2 bg-accent rounded-full mr-2"></div>
            No credit card required
          </div>
          <div className="flex items-center">
            <div className="w-2 h-2 bg-accent rounded-full mr-2"></div>
            Cancel anytime
          </div>
          <div className="flex items-center">
            <div className="w-2 h-2 bg-accent rounded-full mr-2"></div>
            14-day free trial
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTA;