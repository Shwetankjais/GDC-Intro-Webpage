import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const FAQ = () => {
  const faqs = [
    {
      question: "How does the AI recommendation system work?",
      answer: "Our AI analyzes your viewing history, ratings, time spent watching, and even the time of day you watch to create a comprehensive taste profile. It continuously learns from your behavior and compares it with millions of other users to suggest content you'll love."
    },
    {
      question: "Can I use AIStream on multiple devices?",
      answer: "Yes! Your AIStream account works on all your devices - smartphones, tablets, computers, smart TVs, and streaming devices. You can start watching on one device and seamlessly continue on another."
    },
    {
      question: "What's included in the free trial?",
      answer: "The free trial includes full access to our entire content library, AI recommendations, offline downloads, and streaming on up to 4 devices simultaneously. No credit card required to start."
    },
    {
      question: "How accurate are the AI recommendations?",
      answer: "Our AI achieves 94% accuracy in predicting what users will enjoy. The system becomes more accurate the more you use it, learning your unique preferences and mood patterns."
    },
    {
      question: "Can I download content for offline viewing?",
      answer: "Yes! Our Smart Downloads feature not only lets you manually download content but also uses AI to predict and automatically download shows and movies you're likely to watch next."
    },
    {
      question: "Is my viewing data private and secure?",
      answer: "Absolutely. We use enterprise-grade encryption and never sell your personal data. Your viewing preferences are used solely to improve your experience and recommendations."
    }
  ];

  return (
    <section className="py-20 px-4 bg-gradient-card">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-bold mb-6 text-foreground">
            Frequently Asked Questions
          </h2>
          <p className="text-xl text-muted-foreground">
            Everything you need to know about AIStream and our revolutionary platform.
          </p>
        </div>

        <Accordion type="single" collapsible className="space-y-4">
          {faqs.map((faq, index) => (
            <AccordionItem 
              key={index} 
              value={`item-${index}`}
              className="bg-card/80 backdrop-blur-sm border border-border/50 rounded-lg px-6 hover:shadow-glow transition-all duration-300"
            >
              <AccordionTrigger className="text-left text-lg font-semibold text-card-foreground hover:text-accent">
                {faq.question}
              </AccordionTrigger>
              <AccordionContent className="text-card-foreground/80 pb-4">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

export default FAQ;