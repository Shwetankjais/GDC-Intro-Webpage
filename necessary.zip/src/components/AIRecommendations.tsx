import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Brain, Heart, Clock, Star } from "lucide-react";
import aiImage from "@/assets/ai-recommendation.jpg";

interface Recommendation {
  id: number;
  title: string;
  genre: string;
  rating: number;
  duration: string;
  description: string;
  mood: string;
  aiScore: number;
}

const AIRecommendations = () => {
  const [selectedMood, setSelectedMood] = useState<string>("");
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const moods = [
    { id: "adventure", label: "Adventure", icon: "🚀" },
    { id: "romance", label: "Romance", icon: "💕" },
    { id: "thriller", label: "Thriller", icon: "⚡" },
    { id: "comedy", label: "Comedy", icon: "😄" },
    { id: "drama", label: "Drama", icon: "🎭" },
    { id: "scifi", label: "Sci-Fi", icon: "👽" }
  ];

  const generateRecommendations = async (mood: string) => {
    setIsLoading(true);
    setSelectedMood(mood);
    
    // Simulate AI processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const mockRecommendations: Recommendation[] = [
      {
        id: 1,
        title: "Quantum Horizons",
        genre: "Sci-Fi Drama",
        rating: 9.2,
        duration: "2h 15m",
        description: "A mind-bending journey through parallel dimensions.",
        mood: mood,
        aiScore: 98
      },
      {
        id: 2,
        title: "Digital Hearts",
        genre: "Romance Tech",
        rating: 8.7,
        duration: "1h 45m",
        description: "Love in the age of artificial intelligence.",
        mood: mood,
        aiScore: 95
      },
      {
        id: 3,
        title: "Neural Network",
        genre: "Thriller Mystery",
        rating: 9.0,
        duration: "2h 05m",
        description: "When AI becomes the hunter and the hunted.",
        mood: mood,
        aiScore: 92
      }
    ];
    
    setRecommendations(mockRecommendations);
    setIsLoading(false);
  };

  return (
    <section className="py-20 px-4 bg-gradient-card">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <div className="flex justify-center mb-6">
            <div className="relative">
              <Brain className="w-16 h-16 text-accent animate-pulse" />
              <Sparkles className="w-8 h-8 text-primary absolute -top-2 -right-2 animate-glow" />
            </div>
          </div>
          
          <h2 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-foreground to-accent bg-clip-text text-transparent">
            AI-Powered Recommendations
          </h2>
          
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
            Our advanced neural networks analyze your viewing patterns, mood, and preferences 
            to curate the perfect entertainment experience just for you.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <img 
              src={aiImage} 
              alt="AI Recommendation Engine"
              className="w-full rounded-2xl shadow-glow"
            />
          </div>
          
          <div>
            <h3 className="text-3xl font-bold mb-6 text-foreground">
              Tell us your mood, get perfect matches
            </h3>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-8">
              {moods.map((mood) => (
                <Button
                  key={mood.id}
                  variant={selectedMood === mood.id ? "ai" : "secondary"}
                  onClick={() => generateRecommendations(mood.id)}
                  className="flex flex-col items-center p-4 h-auto group"
                  disabled={isLoading}
                >
                  <span className="text-2xl mb-2 group-hover:scale-110 transition-transform">
                    {mood.icon}
                  </span>
                  <span className="text-sm">{mood.label}</span>
                </Button>
              ))}
            </div>

            {isLoading && (
              <div className="text-center py-8">
                <div className="inline-flex items-center space-x-2">
                  <Brain className="w-6 h-6 text-accent animate-spin" />
                  <span className="text-accent">AI is analyzing your preferences...</span>
                </div>
              </div>
            )}

            {recommendations.length > 0 && !isLoading && (
              <div className="space-y-4">
                <h4 className="text-xl font-semibold text-foreground mb-4">
                  Perfect matches for your {selectedMood} mood:
                </h4>
                {recommendations.map((rec) => (
                  <Card key={rec.id} className="bg-card/80 backdrop-blur-sm border-border/50 hover:shadow-glow transition-all duration-300">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-lg text-card-foreground">{rec.title}</CardTitle>
                          <CardDescription className="text-muted-foreground">{rec.genre}</CardDescription>
                        </div>
                        <Badge variant="secondary" className="bg-accent/20 text-accent">
                          <Sparkles className="w-3 h-3 mr-1" />
                          {rec.aiScore}% Match
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-card-foreground/80 mb-3">{rec.description}</p>
                      <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                        <div className="flex items-center">
                          <Star className="w-4 h-4 text-accent mr-1" />
                          {rec.rating}
                        </div>
                        <div className="flex items-center">
                          <Clock className="w-4 h-4 mr-1" />
                          {rec.duration}
                        </div>
                        <div className="flex items-center">
                          <Heart className="w-4 h-4 mr-1" />
                          {rec.mood}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AIRecommendations;